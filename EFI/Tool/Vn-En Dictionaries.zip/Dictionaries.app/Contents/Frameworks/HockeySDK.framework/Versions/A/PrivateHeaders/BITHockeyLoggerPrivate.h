#import "BITHockeyLogger.h"

FOUNDATION_EXPORT BITLogHandler const defaultLogHandler;
